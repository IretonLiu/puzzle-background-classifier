import glob
import cv2
import matplotlib.pyplot as plt
import numpy as np
from sklearn import cluster
from gmm import GaussianMixtureModel
from scipy.stats import multivariate_normal
from ellipsoid import get_cov_ellipsoid
from sklearn.mixture import GaussianMixture
from classifier import Classifier

res = (1024, 768)


def read_data():
    # glob all images from data
    image_files = glob.glob('data/images-1024x768/*.png')
    mask_files = glob.glob('data/masks-1024x768/*.png')

    # convert to images using cv2 and convert to float RGB
    images = np.array([cv2.cvtColor(cv2.imread(image), cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
                       for image in image_files])
    masks = np.array([cv2.cvtColor(cv2.imread(mask), cv2.COLOR_BGR2GRAY) > 0
                      for mask in mask_files])

    return images, masks


def split_dataset(images, masks):
    # split the images and masks into training validation and test with ration 70:15:15
    training_images = images[:int(len(images) * 0.7)]
    validation_images = images[int(len(images) * 0.7):int(len(images) * 0.85)]
    testing_images = images[int(len(images) * 0.85):]

    training_masks = masks[:int(len(masks) * 0.7)]
    validation_masks = masks[int(len(masks) * 0.7):int(len(masks) * 0.85)]
    testing_masks = masks[int(len(masks) * 0.85):]

    return training_images, validation_images, testing_images, training_masks, validation_masks, testing_masks


def scatter_plot(data, step, gmm=None):
    # 3d scatter plot of train_data_foreground
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.scatter(
        data[::step, 0], data[::step, 1], data[::step, 2])

    ax.set_xlabel('X Label')
    ax.set_ylabel('Y Label')
    ax.set_zlabel('Z Label')
    if gmm:
        for j in range(gmm.n_components):
            # plot the gaussian
            x, y, z = get_cov_ellipsoid(gmm.covariances_[j], gmm.means_[j])
            ax.plot_surface(x, y, z, color='r', alpha=0.1)
    plt.show()


def to_feature_vector(images, feature_type):
    # convert images to feature vectors

    if feature_type == 'rgb':
        # flatten the images
        return images.reshape(-1, 3)
    elif feature_type == 'hsv':
        # convert to hsv
        return np.array([cv2.cvtColor(image, cv2.COLOR_RGB2HSV).reshape(-1, 3)
                         for image in images])
    elif feature_type == 'rgb+dog':
        dog = np.array([cv2.GaussianBlur(image, (3, 3), 0) -
                       cv2.GaussianBlur(image, (5, 5), 0) for image in images])
        return np.hstack((images.reshape(-1, 3), dog.reshape(-1, 3)))
    else:
        raise ValueError('Unknown feature type')


def main():

    images, masks = read_data()
    train_images, val_images, test_images, train_masks, val_masks, test_masks = split_dataset(
        images, masks)

    # convert to pixels
    # train_data = np.concatenate([image.reshape(-1, 3)
    #                              for image in train_images])

    # list of feature sets to use
    features = ["rgb", "rgb+dog", "hsv", ]
    to_feature_vector(images, "hsv")
    foreground_h_list = [2, 3, 4, 5, 6]
    background_h_list = [2, 3, 4, 5, 6]
    if 1:

        # fit the model
        for feature in features:
            print("Training with feature: {}".format(feature))
            # convert to feature vectors
            train_data = to_feature_vector(train_images[:10], feature)
            train_data_masks = train_masks[:10].reshape(-1, 1)

            train_data_foreground = train_data[train_data_masks[:, 0]]
            train_data_background = train_data[~train_data_masks[:, 0]]

            for background_h in background_h_list:
                print("Training background GMM with h = {}".format(background_h))
                gmm_background = GaussianMixtureModel(
                    2, train_data_background.shape[1], max_iter=5, seed=4)
                gmm_background.fit(train_data_background)
                gmm_background.save_model(
                    f"models/gmm/{feature}/background/{background_h}/")

            for foreground_h in foreground_h_list:
                print("Training foreground GMM with h = {}".format(foreground_h))
                gmm_foreground = GaussianMixtureModel(
                    6, train_data_foreground.shape[1], max_iter=5, seed=2)
                gmm_foreground.fit(train_data_foreground)
                gmm_foreground.save_model(
                    f"models/gmm/{feature}/foreground/{foreground_h}/")
            print("=============================================================")

    # gm = GaussianMixture(n_components=3, covariance_type='full', max_iter=100)
    # gm.fit(train_data_foreground)

    # plot = True
    # if plot:
    #     scatter_plot(train_data_foreground, 1000, gmm_foreground)
    #     scatter_plot(train_data_background, 1000, gmm_background)
    if 0:
        gmm_foreground = GaussianMixtureModel(
            6, train_data_foreground.shape[1], max_iter=100, seed=2)
        gmm_background = GaussianMixtureModel(
            6, train_data_background.shape[1], max_iter=100, seed=4)
        gmm_foreground.load_model("models/gmm/rgb/foreground/6/")
        gmm_background.load_model("models/gmm/rgb/background/6/")

        # scatter_plot(train_data_foreground, 10000, gmm_foreground)
        # scatter_plot(train_data_background, 10000, gmm_background)

        # test the model
        classifier = Classifier(train_data, train_data_masks)
        likelihoods = [gmm_background, gmm_foreground]
        probabilities = classifier.maximum_a_posteriori(likelihoods)
        predictions = np.argmax(probabilities, axis=0) == 1
        print("Training accuracy: ", np.sum(predictions ==
                                            train_data_masks[:, 0]) / len(train_data_masks))


if __name__ == "__main__":
    main()
